package com.lab.jutransportalpha;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class UserProfileActivity extends AppCompatActivity {

    EditText userNameInput, departmentInput, hallInput, batchInput;
    Button editButton, saveButton, cancelButton;

    boolean isEditing = false;

    @SuppressLint({"SetTextI18n", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Initialize views
        userNameInput = findViewById(R.id.userNameInput);
        departmentInput = findViewById(R.id.departmentInput);
        hallInput = findViewById(R.id.hallInput);
        batchInput = findViewById(R.id.batchInput);
        editButton = findViewById(R.id.editButton);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Set default values (Replace with actual user data from the database later)
        userNameInput.setText("Rayuga");
        departmentInput.setText("CSE");
        hallInput.setText("Hall Z");
        batchInput.setText("Batch 49");

        // Set OnClickListener for the Edit button
        editButton.setOnClickListener(view -> {
            if (isEditing) {
                // Save changes logic here (update database)
                // For now, just disable the inputs
                saveProfile(); // Call save profile function
            } else {
                // Allow user to edit the fields
                enableEditing(true);
                editButton.setText("Save"); // Change button text to Save
                isEditing = true; // Set editing state to true
                saveButton.setVisibility(View.VISIBLE); // Show Save button
                cancelButton.setVisibility(View.VISIBLE); // Show Cancel button
            }
        });

        // Set OnClickListener for the Save button
        saveButton.setOnClickListener(view -> {
            saveProfile(); // Call save profile function
        });

        // Set OnClickListener for the Cancel button
        cancelButton.setOnClickListener(v -> {
            // Discard changes and reset fields
            resetFields();
            enableEditing(false);
        });
    }

    private void enableEditing(boolean enable) {
        userNameInput.setFocusableInTouchMode(enable);
        departmentInput.setFocusableInTouchMode(enable);
        hallInput.setFocusableInTouchMode(enable);
        batchInput.setFocusableInTouchMode(enable);
    }

    @SuppressLint("SetTextI18n")
    private void saveProfile() {
        // Logic to save the updated user profile
        // Include database operations

        // For demo purposes,  just disable the inputs
        enableEditing(false);
        editButton.setText("Edit"); // Change button text back to Edit
        isEditing = false; // Set editing state to false
        saveButton.setVisibility(View.GONE); // Hide Save button
        cancelButton.setVisibility(View.GONE); // Hide Cancel button
    }

    @SuppressLint("SetTextI18n")
    private void resetFields() {
        // Reset to original values (for demo)
        userNameInput.setText("John Doe");
        departmentInput.setText("Computer Science");
        hallInput.setText("Hall A");
        batchInput.setText("Batch 2024");
    }
}

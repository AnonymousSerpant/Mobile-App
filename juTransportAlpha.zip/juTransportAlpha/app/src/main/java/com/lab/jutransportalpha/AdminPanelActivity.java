package com.lab.jutransportalpha;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AdminPanelActivity extends AppCompatActivity {

    Button reportsButton, driverListButton, paymentButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        // Initialize buttons
        reportsButton = findViewById(R.id.reportsButton);
        driverListButton = findViewById(R.id.driverListButton);
        paymentButton = findViewById(R.id.paymentButton);

        // Set OnClickListeners for the buttons
        reportsButton.setOnClickListener(v -> {
            // Navigate to Reports page (replace ReportsActivity.class with your actual activity)
            Intent intent = new Intent(AdminPanelActivity.this, ReportsActivity.class);
            startActivity(intent);
        });

        driverListButton.setOnClickListener(v -> {
            // Navigate to Driver List page (replace DriverListActivity.class with your actual activity)
            Intent intent = new Intent(AdminPanelActivity.this, DriverListActivity.class);
            startActivity(intent);
        });

        paymentButton.setOnClickListener(v -> {
            // Navigate to Payment page (replace PaymentActivity.class with your actual activity)
            Intent intent = new Intent(AdminPanelActivity.this, PaymentActivity.class);
            startActivity(intent);
        });
    }
}

package com.lab.jutransportalpha;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginActivity extends AppCompatActivity {

    EditText phoneNumberInput, passwordInput;
    Button logInButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        // Initialize views
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        passwordInput = findViewById(R.id.passwordInput);
        logInButton = findViewById(R.id.logInButton);

        // Set OnClickListener for the Log In button
        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Here add logic to validate the credentials
                // For now just redirect to AdminPanelActivity
                Intent intent = new Intent(AdminLoginActivity.this, AdminPanelActivity.class);
                startActivity(intent);
                finish(); // Optional
            }
        });
    }
}

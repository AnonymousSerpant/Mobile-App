package com.lab.jutransportalpha;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LiveFeedActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_feed);

        // Get the route name passed from HomeActivity
        String routeName = getIntent().getStringExtra("routeName");

        // Set the route name as the title for the live feed
        TextView routeTitle = findViewById(R.id.routeTitle);
        routeTitle.setText("Live Feed: " + routeName);

        // The placeholder TextView can be replaced with live feed content later
        TextView liveFeedPlaceholder = findViewById(R.id.liveFeedPlaceholder);
        liveFeedPlaceholder.setText("Displaying live feed for " + routeName + ".");
    }
}

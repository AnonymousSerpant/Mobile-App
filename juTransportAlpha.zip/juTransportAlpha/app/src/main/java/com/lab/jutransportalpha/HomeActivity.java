package com.lab.jutransportalpha;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Objects;

public class HomeActivity extends AppCompatActivity {

    ListView busRouteListView;
    String[] busRoutes = {"Route 1", "Route 2", "Route 3", "Route 4", "Route 5", "Route 6", "Route 7"};
    FloatingActionButton fabMenu;

    // Example user name
    String userName = "User"; // Fetch this dynamically based on app logic

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        // Set edge-to-edge system insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the ListView for bus routes
        busRouteListView = findViewById(R.id.busRouteList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, busRoutes);
        busRouteListView.setAdapter(adapter);

        // Handle bus route selection
        busRouteListView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(HomeActivity.this, LiveFeedActivity.class);
            intent.putExtra("routeName", busRoutes[position]);
            startActivity(intent);
        });

        // Set up Floating Action Button and Popup Menu
        fabMenu = findViewById(R.id.fabMenu);
        fabMenu.setOnClickListener(this::showUserOptionsMenu);
    }

    private void showUserOptionsMenu(View view) {
        // Create a PopupMenu
        PopupMenu popupMenu = new PopupMenu(HomeActivity.this, view);

        // Add menu items
        popupMenu.getMenu().add(userName); // Show the user's name
        popupMenu.getMenu().add("Admin Login");

        // Set up menu item click listener
        popupMenu.setOnMenuItemClickListener(menuItem -> {
            if (Objects.equals(menuItem.getTitle(), userName)) {
                // Navigate to User Profile page
                Intent userIntent = new Intent(HomeActivity.this, UserProfileActivity.class);
                startActivity(userIntent);
            } else if (Objects.requireNonNull(menuItem.getTitle()).equals("Admin Login")) {
                // Navigate to Admin Login Console page
                Intent adminIntent = new Intent(HomeActivity.this, AdminLoginActivity.class);
                startActivity(adminIntent);
            }
            return true;
        });

        // Show the popup menu
        popupMenu.show();
    }
}
